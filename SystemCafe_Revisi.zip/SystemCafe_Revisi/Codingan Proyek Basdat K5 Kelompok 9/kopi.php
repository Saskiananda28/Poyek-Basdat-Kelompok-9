<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>

<?php

// Create Kopi
if(isset($_POST['create_kopi'])){
    $id = $_POST['id_menu'];
    $ukuran = $_POST['ukuran'];

    $res = pg_query_params($conn,
        "INSERT INTO Kopi (ID_Menu, Ukuran_Cup) VALUES ($1, $2)",
        array($id, $ukuran)
    );

    if($res) echo '<div class="msg success">Data Kopi ditambahkan.</div>';
    else echo '<div class="msg error">'.pg_last_error($conn).'</div>';
}

// Delete Kopi
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $res = pg_query_params($conn,
        "DELETE FROM Kopi WHERE ID_Menu = $1",
        array($id)
    );

    if($res) echo '<div class="msg success">Kopi dihapus.</div>';
}

// Ambil data
$result = pg_query($conn,
    "SELECT k.*, m.NamaMenu
     FROM Kopi k
     JOIN Menu m ON k.ID_Menu = m.ID_Menu
     ORDER BY k.ID_Menu"
);
?>

<h1>Data Kopi</h1>

<h3>Tambah Kopi</h3>
<form method="post">
    <input name="id_menu" placeholder="ID Menu (M00X)" required>
    <input name="ukuran" placeholder="Ukuran Cup (Small/Medium/Large)" required>
    <button name="create_kopi">Simpan</button>
</form>

<h3>Daftar Kopi</h3>
<table>
<tr>
    <th>ID Menu</th>
    <th>Nama Menu</th>
    <th>Ukuran Cup</th>
    <th>Aksi</th>
</tr>

<?php while($r = pg_fetch_assoc($result)): ?>
<tr>
    <td><?= $r['id_menu'] ?></td>
    <td><?= $r['namamenu'] ?></td>
    <td><?= $r['ukuran_cup'] ?></td>
    <td>
        <a href="?delete=<?= $r['id_menu'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
