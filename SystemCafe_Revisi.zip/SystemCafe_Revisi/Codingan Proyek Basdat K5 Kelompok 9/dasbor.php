<?php 
// Kalau butuh session login, bisa aktifkan:
// session_start();
// if(!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffe & Cheesecake - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
/* ===========================
   CSS ASLI KAMU DISATUKAN
   =========================== */

/* Reset Dasar */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background-color: #F9F7F3;
    color: #333333;
}

/* ===== APP CONTAINER ===== */
.app-container {
    display: flex;
    min-height: 100vh;
    width: 100%;
    max-width: 1400px;
    margin: 0 auto;
    background-color: white;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
    border-radius: 15px;
    overflow: hidden;
}

/* ===== SIDEBAR ===== */
.sidebar {
    width: 250px;
    padding: 20px;
    background-color: #ffffff;
    border-right: 1px solid #eeeeee;
    display: flex;
    flex-direction: column;
}

.logo h3 {
    color: #FF7F50;
    margin-bottom: 40px;
    font-size: 1.5rem;
}

.main-nav ul {
    list-style: none;
    padding: 0;
}

.main-nav li {
    margin-bottom: 5px;
}

.main-nav a {
    display: block;
    padding: 10px 15px;
    text-decoration: none;
    color: #666666;
    border-radius: 8px;
    transition: 0.2s;
}

.main-nav a:hover {
    background-color: #FF7F50;
    color: white;
}

.main-nav a.active {
    background-color: #FF7F50;
    color: white;
    font-weight: 600;
}

/* Submenu */
.submenu {
    list-style: none;
    padding-left: 20px;
    margin-top: 5px;
}

.submenu a {
    padding: 5px 15px;
    font-size: 0.9rem;
}

.submenu a:hover {
    background-color: #ffe0d5;
    color: #FF7F50;
}

.sidebar-bottom {
    margin-top: auto;
    padding-top: 20px;
    border-top: 1px solid #eeeeee;
}

.logout {
    color: #FF7F50 !important;
}

.logout:hover {
    background-color: #FF7F50 !important;
    color: white !important;
}

/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    padding: 40px;
    overflow-y: auto;
}

/* Dashboard Cards */
.dashboard-stats {
    display: flex;
    gap: 20px;
    margin-top: 20px;
}

.stat-card {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    flex: 1;
    text-align: center;
    border-left: 5px solid #FF7F50;
}

.stat-card h4 {
    color: #666666;
    margin-bottom: 10px;
}

.stat-card p {
    font-size: 2rem;
    font-weight: 700;
    color: #FF7F50;
}
</style>

</head>
<body>

<div class="app-container">
    <aside class="sidebar">
        <div class="logo">
            <h3>Coffe & Cheesecake</h3>
        </div>
        <nav class="main-nav">
            <ul>
                <li><a href="dashboard.php" class="nav-item active">Home</a></li>
                <li><a href="pelanggan.php" class="nav-item">Pelanggan</a></li>
                <li><a href="admin.php" class="nav-item">Admin</a></li>

                <li>
                    <a href="#" class="nav-item menu-dropdown">Menu 🔽</a>
                    <ul class="submenu">
                        <li><a href="kopi.php">Kopi</a></li>
                        <li><a href="cheesecake.php">Cheesecake</a></li>
                    </ul>
                </li>

                <li><a href="pesanan.php" class="nav-item">Pesanan</a></li>
                <li><a href="detail_pesanan.php" class="nav-item">Detail Pesanan</a></li>
            </ul>
        </nav>

        <div class="sidebar-bottom">
            <a href="login.php" class="nav-item logout">Logout</a>
        </div>
    </aside>

    <main class="main-content" id="mainContent">
        <h1>Selamat Datang di Dashboard!</h1>
        <div class="dashboard-stats">
            <div class="stat-card">
                <h4>Total Pelanggan</h4>
                <p>5</p>
            </div>
            <div class="stat-card">
                <h4>Total Menu</h4>
                <p>6</p>
            </div>
            <div class="stat-card">
                <h4>Total Pesanan</h4>
                <p>5</p>
            </div>
        </div>
    </main>
</div>

</body>
</html>