<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>

<?php

// Create pesanan
if (isset($_POST['create_order'])) {
    $id = $_POST['id_pesanan'];
    $id_pelanggan = $_POST['id_pelanggan'];
    $id_admin = $_POST['id_admin'];
    $tanggal = $_POST['tanggal'];

    $res = pg_query_params($conn,
        "INSERT INTO Pesanan (ID_Pesanan, ID_Pelanggan, ID_Admin, Tanggal)
         VALUES ($1, $2, $3, $4)",
        array($id, $id_pelanggan, $id_admin, $tanggal)
    );

    if ($res) echo '<div class="msg success">Pesanan ditambahkan.</div>';
    else echo '<div class="msg error">Error: ' . pg_last_error($conn) . '</div>';
}

// Update pesanan
if (isset($_POST['update_order'])) {
    $id = $_POST['id_pesanan'];
    $id_pelanggan = $_POST['id_pelanggan'];
    $id_admin = $_POST['id_admin'];
    $tanggal = $_POST['tanggal'];

    $res = pg_query_params($conn,
        "UPDATE Pesanan SET ID_Pelanggan=$1, ID_Admin=$2, Tanggal=$3
         WHERE ID_Pesanan=$4",
        array($id_pelanggan, $id_admin, $tanggal, $id)
    );

    if ($res) echo '<div class="msg success">Pesanan diperbarui.</div>';
}

// Delete pesanan
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $res = pg_query_params($conn,
        "DELETE FROM Pesanan WHERE ID_Pesanan=$1",
        array($id)
    );

    if ($res) echo '<div class="msg success">Pesanan dihapus.</div>';
}

// Ambil data untuk edit
$edit = null;
if (isset($_GET['edit'])) {
    $result = pg_query_params($conn,
        "SELECT * FROM Pesanan WHERE ID_Pesanan=$1",
        array($_GET['edit'])
    );
    $edit = pg_fetch_assoc($result);
}

// Ambil data dropdown
$pelanggan_list = pg_query($conn, "SELECT ID_Pelanggan, NamaPelanggan FROM Pelanggan ORDER BY ID_Pelanggan");
$admin_list = pg_query($conn, "SELECT ID_Admin, NamaAdmin FROM AdminCafe ORDER BY ID_Admin");

// Ambil seluruh pesanan
$pesanan = pg_query($conn,
    "SELECT ps.ID_Pesanan, ps.ID_Pelanggan, ps.ID_Admin, ps.Tanggal,
            p.NamaPelanggan, a.NamaAdmin
     FROM Pesanan ps
     JOIN Pelanggan p ON ps.ID_Pelanggan = p.ID_Pelanggan
     JOIN AdminCafe a ON ps.ID_Admin = a.ID_Admin
     ORDER BY ps.ID_Pesanan"
);
?>

<h1>Data Pesanan</h1>

<?php if ($edit): ?>
<h3>Edit Pesanan</h3>
<form method="post">
    <input type="hidden" name="id_pesanan" value="<?= $edit['id_pesanan'] ?>">

    <select name="id_pelanggan">
        <?php
        pg_result_seek($pelanggan_list, 0);
        while ($p = pg_fetch_assoc($pelanggan_list)):
            $sel = ($p['id_pelanggan'] == $edit['id_pelanggan']) ? 'selected' : '';
        ?>
            <option value="<?= $p['id_pelanggan'] ?>" <?= $sel ?>>
                <?= $p['id_pelanggan'] . ' - ' . $p['namapelanggan'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <select name="id_admin">
        <?php
        pg_result_seek($admin_list, 0);
        while ($a = pg_fetch_assoc($admin_list)):
            $sel = ($a['id_admin'] == $edit['id_admin']) ? 'selected' : '';
        ?>
            <option value="<?= $a['id_admin'] ?>" <?= $sel ?>>
                <?= $a['id_admin'] . ' - ' . $a['namaadmin'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <input type="date" name="tanggal" value="<?= $edit['tanggal'] ?>">

    <button name="update_order">Update</button>
</form>
<?php endif; ?>

<h3>Tambah Pesanan</h3>
<form method="post">
    <input name="id_pesanan" placeholder="T00X" required>

    <select name="id_pelanggan">
        <?php
        pg_result_seek($pelanggan_list, 0);
        while ($p = pg_fetch_assoc($pelanggan_list)):
        ?>
            <option value="<?= $p['id_pelanggan'] ?>">
                <?= $p['id_pelanggan'] . ' - ' . $p['namapelanggan'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <select name="id_admin">
        <?php
        pg_result_seek($admin_list, 0);
        while ($a = pg_fetch_assoc($admin_list)):
        ?>
            <option value="<?= $a['id_admin'] ?>">
                <?= $a['id_admin'] . ' - ' . $a['namaadmin'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>">

    <button name="create_order">Simpan</button>
</form>

<h3>Daftar Pesanan</h3>
<table>
<tr>
    <th>ID Pesanan</th>
    <th>Pelanggan</th>
    <th>Admin</th>
    <th>Tanggal</th>
    <th>Aksi</th>
</tr>

<?php while ($row = pg_fetch_assoc($pesanan)): ?>
<tr>
    <td><?= $row['id_pesanan'] ?></td>
    <td><?= $row['namapelanggan'] ?></td>
    <td><?= $row['namaadmin'] ?></td>
    <td><?= $row['tanggal'] ?></td>
    <td>
        <a href="?edit=<?= $row['id_pesanan'] ?>">Edit</a> |
        <a href="?delete=<?= $row['id_pesanan'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>