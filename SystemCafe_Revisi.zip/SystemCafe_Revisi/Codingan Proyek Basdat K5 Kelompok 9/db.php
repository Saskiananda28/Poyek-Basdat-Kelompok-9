<?php
$host = 'localhost';
$dbname = 'SystemCafe';
$user = 'postgres';
$password = 'postgres';

$conn = pg_connect("host=$host dbname=$dbname user=$user
password=$password");
if (!$conn) {
die("Koneksi gagal: " . pg_last_error());
}
?>