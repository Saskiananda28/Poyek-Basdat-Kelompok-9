<?php
session_start();
include 'db.php';   // Koneksi ke database

$pesan_error = "";

// Cek submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_input = $_POST['username'];
    $password_input = $_POST['password'];

    // Query: cek username + password
    $result = pg_query_params($conn,
        "SELECT * FROM AdminCafe WHERE Akun = $1 AND Password = $2",
        array($username_input, $password_input)
    );

    // Jika ada data cocok → login berhasil
    if ($row = pg_fetch_assoc($result)) {

        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $row['namaadmin'];
        $_SESSION['id_admin'] = $row['id_admin'];

        header("Location: index.php");
        exit;

    } else {
        $pesan_error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Cafe</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #F8F8F4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #FFFFFF;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 300px;
            text-align: center;
        }
        .logo {
            color: #A38C55;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        button {
            background-color: #A38C55;
            color: white;
            padding: 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
        }
        button:hover {
            background-color: #8C7B4A;
        }
        .error {
            color: red;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="logo">Coffe & Cheesecake</div>

    <?php if ($pesan_error): ?>
        <p class="error"><?= $pesan_error ?></p>
    <?php endif; ?>

    <form method="POST">
        <label><b>Username</b></label>
        <input type="text" name="username" placeholder="Masukkan Username" required>

        <label><b>Password</b></label>
        <input type="password" name="password" placeholder="Masukkan Password" required>

        <button type="submit">Sign In</button>
    </form>
</div>

</body>
</html>