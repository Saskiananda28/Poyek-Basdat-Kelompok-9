<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>

<?php
// Create
if(isset($_POST['create_pelanggan'])){
    $id = $_POST['id_pelanggan'];
    $nama = trim($_POST['nama']);
    $hp = trim($_POST['hp']);
    $alamat = trim($_POST['alamat']);
    if($id && $nama && $hp){
        $q = "INSERT INTO Pelanggan (ID_Pelanggan,NamaPelanggan,NomorHP,Alamat) VALUES ($1,$2,$3,$4)";
        $res = pg_query_params($conn, $q, array($id,$nama,$hp,$alamat));
        if($res) echo '<div class="msg success">Pelanggan ditambahkan.</div>';
        else echo '<div class="msg error">Gagal: '.pg_last_error($conn).'</div>';
    }
}
// Update
if(isset($_POST['update_pelanggan'])){
    $id = $_POST['id_pelanggan'];
    $nama = trim($_POST['nama']);
    $hp = trim($_POST['hp']);
    $alamat = trim($_POST['alamat']);
    $q = "UPDATE Pelanggan SET NamaPelanggan=$1, NomorHP=$2, Alamat=$3 WHERE ID_Pelanggan=$4";
    $res = pg_query_params($conn,$q,array($nama,$hp,$alamat,$id));
    if($res) echo '<div class="msg success">Pelanggan diperbarui.</div>';
    else echo '<div class="msg error">Gagal: '.pg_last_error($conn).'</div>';
}
// Delete
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $res = pg_query_params($conn,"DELETE FROM Pelanggan WHERE ID_Pelanggan=$1",array($id));
    if($res) echo '<div class="msg success">Pelanggan dihapus.</div>';
}
// Ambil edit data
$edit=null;
if(isset($_GET['edit'])){
    $r = pg_query_params($conn,"SELECT * FROM Pelanggan WHERE ID_Pelanggan=$1",array($_GET['edit']));
    $edit = pg_fetch_assoc($r);
}
// Tampilkan semua
$result = pg_query($conn,"SELECT * FROM Pelanggan ORDER BY ID_Pelanggan");
?>
<h1>Data Pelanggan</h1>
<?php if($edit): ?>
<h3>Edit Pelanggan</h3>
<form method="post"><input type="hidden" name="id_pelanggan" value="<?=htmlspecialchars($edit['id_pelanggan'])?>">
  <input name="nama" value="<?=htmlspecialchars($edit['namapelanggan'])?>" required>
  <input name="hp" value="<?=htmlspecialchars($edit['nomorhp'])?>" required>
  <input name="alamat" value="<?=htmlspecialchars($edit['alamat'])?>">
  <button name="update_pelanggan">Update</button>
</form>
<?php endif; ?>

<h3>Tambah Pelanggan</h3>
<form method="post">
  <input name="id_pelanggan" placeholder="ID (ex P006)" required>
  <input name="nama" placeholder="Nama" required>
  <input name="hp" placeholder="Nomor HP" required>
  <input name="alamat" placeholder="Alamat">
  <button name="create_pelanggan">Simpan</button>
</form>

<h3>List Pelanggan</h3>
<table><tr><th>ID</th><th>Nama</th><th>HP</th><th>Alamat</th><th>Aksi</th></tr>
<?php while($row = pg_fetch_assoc($result)): ?>
<tr>
  <td><?=htmlspecialchars($row['id_pelanggan'])?></td>
  <td><?=htmlspecialchars($row['namapelanggan'])?></td>
  <td><?=htmlspecialchars($row['nomorhp'])?></td>
  <td><?=htmlspecialchars($row['alamat'])?></td>
  <td><a href="?edit=<?=urlencode($row['id_pelanggan'])?>">Edit</a> | <a href="?delete=<?=urlencode($row['id_pelanggan'])?>" onclick="return confirm('Yakin?')">Hapus</a></td>
</tr>
<?php endwhile; ?>
</table>
<?php include 'footer.php'; ?>