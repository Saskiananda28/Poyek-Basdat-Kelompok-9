<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>

<?php

// Create Item Pesanan
if(isset($_POST['create_item'])){
    $id = $_POST['id_detail'];
    $id_pesanan = $_POST['id_pesanan'];
    $id_menu = $_POST['id_menu'];
    $jumlah = $_POST['jumlah'];

    $res = pg_query_params($conn,
        "INSERT INTO Detail_Pesanan (ID_Detail, ID_Pesanan, ID_Menu, Jumlah)
         VALUES ($1, $2, $3, $4)",
        array($id, $id_pesanan, $id_menu, $jumlah)
    );

    if($res) echo '<div class="msg success">Item ditambahkan.</div>';
    else echo '<div class="msg error">'.pg_last_error($conn).'</div>';
}

// Update item
if(isset($_POST['update_item'])){
    $id = $_POST['id_detail'];
    $jumlah = $_POST['jumlah'];

    $res = pg_query_params($conn,
        "UPDATE Detail_Pesanan SET Jumlah=$1 WHERE ID_Detail=$2",
        array($jumlah, $id)
    );

    if($res) echo '<div class="msg success">Item diperbarui.</div>';
}

// Delete item
if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    $res = pg_query_params($conn,
        "DELETE FROM Detail_Pesanan WHERE ID_Detail=$1",
        array($id)
    );

    if($res) echo '<div class="msg success">Item dihapus.</div>';
}

// Ambil edit data
$edit = null;
if(isset($_GET['edit'])){
    $result = pg_query_params($conn,
        "SELECT * FROM Detail_Pesanan WHERE ID_Detail=$1",
        array($_GET['edit'])
    );
    $edit = pg_fetch_assoc($result);
}

// Ambil menu & pesanan list
$menu_list = pg_query($conn,
    "SELECT ID_Menu, NamaMenu FROM Menu ORDER BY ID_Menu"
);
$pesanan_list = pg_query($conn,
    "SELECT ID_Pesanan FROM Pesanan ORDER BY ID_Pesanan"
);

// All detail
$detail = pg_query($conn,
    "SELECT dp.*, m.NamaMenu
     FROM Detail_Pesanan dp
     JOIN Menu m ON dp.ID_Menu=m.ID_Menu
     ORDER BY dp.ID_Detail"
);
?>

<h1>Detail Pesanan</h1>

<?php if($edit): ?>
<h3>Edit Item</h3>
<form method="post">
    <input type="hidden" name="id_detail" value="<?= $edit['id_detail'] ?>">
    <input name="jumlah" type="number" min="1" value="<?= $edit['jumlah'] ?>">
    <button name="update_item">Update</button>
</form>
<?php endif; ?>

<h3>Tambah Item Pesanan</h3>
<form method="post">
    <input name="id_detail" placeholder="D00X" required>

    <select name="id_pesanan">
        <?php while($p = pg_fetch_assoc($pesanan_list)): ?>
            <option value="<?= $p['id_pesanan'] ?>"><?= $p['id_pesanan'] ?></option>
        <?php endwhile; ?>
    </select>

    <select name="id_menu">
        <?php while($m = pg_fetch_assoc($menu_list)): ?>
            <option value="<?= $m['id_menu'] ?>"><?= $m['id_menu']." - ".$m['namamenu'] ?></option>
        <?php endwhile; ?>
    </select>

    <input name="jumlah" type="number" min="1" value="1">

    <button name="create_item">Simpan</button>
</form>

<h3>Daftar Detail Pesanan</h3>
<table>
<tr>
    <th>ID Detail</th>
    <th>ID Pesanan</th>
    <th>Menu</th>
    <th>Jumlah</th>
    <th>Aksi</th>
</tr>

<?php while($r = pg_fetch_assoc($detail)): ?>
<tr>
    <td><?= $r['id_detail'] ?></td>
    <td><?= $r['id_pesanan'] ?></td>
    <td><?= $r['namamenu'] ?></td>
    <td><?= $r['jumlah'] ?></td>
    <td>
        <a href="?edit=<?= $r['id_detail'] ?>">Edit</a> |
        <a href="?delete=<?= $r['id_detail'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
