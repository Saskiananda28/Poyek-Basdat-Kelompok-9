<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>
<?php

// Create admin
if (isset($_POST['create_admin'])) {
    $id = $_POST['id_admin'];
    $nama = $_POST['nama_admin'];
    $akun = $_POST['akun'];
    $password = $_POST['password'];

    $res = pg_query_params($conn,
        "INSERT INTO AdminCafe (ID_Admin, NamaAdmin, Akun, Password)
         VALUES ($1, $2, $3, $4)",
        array($id, $nama, $akun, $password)
    );

    if ($res) echo '<div class="msg success">Admin ditambahkan.</div>';
    else echo '<div class="msg error">Error: '.pg_last_error($conn).'</div>';
}

// Update admin
if (isset($_POST['update_admin'])) {
    $id = $_POST['id_admin'];
    $nama = $_POST['nama_admin'];
    $akun = $_POST['akun'];
    $password = $_POST['password'];

    $res = pg_query_params($conn,
        "UPDATE AdminCafe
         SET NamaAdmin=$1, Akun=$2, Password=$3
         WHERE ID_Admin=$4",
        array($nama, $akun, $password, $id)
    );

    if ($res) echo '<div class="msg success">Admin diperbarui.</div>';
}

// Delete admin
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $res = pg_query_params($conn,
        "DELETE FROM AdminCafe WHERE ID_Admin=$1",
        array($id)
    );

    if ($res) echo '<div class="msg success">Admin dihapus.</div>';
}

// Ambil data edit
$edit = null;
if (isset($_GET['edit'])) {
    $result = pg_query_params($conn,
        "SELECT * FROM AdminCafe WHERE ID_Admin=$1",
        array($_GET['edit'])
    );
    $edit = pg_fetch_assoc($result);
}

// Ambil semua admin
$admin_list = pg_query($conn,
    "SELECT * FROM AdminCafe ORDER BY ID_Admin"
);
?>

<h1>Data Admin</h1>

<?php if ($edit): ?>
<h3>Edit Admin</h3>
<form method="post">
    <input type="hidden" name="id_admin" value="<?= $edit['id_admin'] ?>">
    <input name="nama_admin" value="<?= $edit['namaadmin'] ?>" placeholder="Nama Admin" required>
    <input name="akun" value="<?= $edit['akun'] ?>" placeholder="Username Admin" required>
    <input type="text" name="password" value="<?= $edit['password'] ?>" placeholder="Password Admin" required>
    <button name="update_admin">Update</button>
</form>
<?php endif; ?>

<h3>Tambah Admin</h3>
<form method="post">
    <input name="id_admin" placeholder="A00X" required>
    <input name="nama_admin" placeholder="Nama Admin" required>
    <input name="akun" placeholder="Username Admin" required>
    <input type="text" name="password" placeholder="Password Admin" required>
    <button name="create_admin">Simpan</button>
</form>

<h3>Daftar Admin</h3>
<table>
<tr>
    <th>ID Admin</th>
    <th>Nama</th>
    <th>Akun</th>
    <th>Password</th>
    <th>Aksi</th>
</tr>

<?php while ($row = pg_fetch_assoc($admin_list)): ?>
<tr>
    <td><?= $row['id_admin'] ?></td>
    <td><?= $row['namaadmin'] ?></td>
    <td><?= $row['akun'] ?></td>
    <td><?= $row['password'] ?></td>
    <td>
        <a href="?edit=<?= $row['id_admin'] ?>">Edit</a> |
        <a href="?delete=<?= $row['id_admin'] ?>" onclick="return confirm('Hapus admin?')">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>