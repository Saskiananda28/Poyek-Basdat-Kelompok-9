<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>

<?php
// CRUD untuk Menu
if(isset($_POST['create_menu'])){
    $id=$_POST['id_menu'];$nama=$_POST['nama'];$harga=(int)$_POST['harga'];$kategori=$_POST['kategori'];
    $res=pg_query_params($conn,"INSERT INTO Menu (ID_Menu,NamaMenu,Harga,Kategori) VALUES ($1,$2,$3,$4)",array($id,$nama,$harga,$kategori));
    if($res) echo '<div class="msg success">Menu ditambahkan.</div>';
}
if(isset($_POST['update_menu'])){
    $id=$_POST['id_menu'];$nama=$_POST['nama'];$harga=(int)$_POST['harga'];$kategori=$_POST['kategori'];
    pg_query_params($conn,"UPDATE Menu SET NamaMenu=$1,Harga=$2,Kategori=$3 WHERE ID_Menu=$4",array($nama,$harga,$kategori,$id)); echo '<div class="msg success">Menu diperbarui.</div>';
}
if(isset($_GET['delete'])){ $id=$_GET['delete']; pg_query_params($conn,"DELETE FROM Menu WHERE ID_Menu=$1",array($id)); echo '<div class="msg success">Menu dihapus.</div>';} 
$edit=null; if(isset($_GET['edit'])){ $r=pg_query_params($conn,"SELECT * FROM Menu WHERE ID_Menu=$1",array($_GET['edit'])); $edit=pg_fetch_assoc($r);} 
$res = pg_query($conn,"SELECT m.*, k.ukuran_cup, c.varianrasa FROM Menu m LEFT JOIN Kopi k ON m.id_menu=k.id_menu LEFT JOIN Cheesecake c ON m.id_menu=c.id_menu ORDER BY m.id_menu");
?>
<h1>Menu</h1>
<?php if($edit): ?>
<form method="post"><input type="hidden" name="id_menu" value="<?=htmlspecialchars($edit['id_menu'])?>"><input name="nama" value="<?=htmlspecialchars($edit['namamenu'])?>"><input name="harga" value="<?=htmlspecialchars($edit['harga'])?>"><select name="kategori"><option <?=($edit['kategori']=='Kopi')?'selected':''?>>Kopi</option><option <?=($edit['kategori']=='Cheesecake')?'selected':''?>>Cheesecake</option><option <?=($edit['kategori']=='Non-Kopi')?'selected':''?>>Non-Kopi</option></select><button name="update_menu">Update</button></form>
<?php endif; ?>
<form method="post"><input name="id_menu" placeholder="M00X" required><input name="nama" placeholder="Nama Menu" required><input name="harga" type="number" min="1" placeholder="Harga" required><select name="kategori"><option>Kopi</option><option>Cheesecake</option><option>Non-Kopi</option></select><button name="create_menu">Simpan</button></form>

<table><tr><th>ID</th><th>Nama</th><th>Harga</th><th>Kategori</th><th>Keterangan</th><th>Aksi</th></tr>
<?php while($r=pg_fetch_assoc($res)): ?>
<tr><td><?=htmlspecialchars($r['id_menu'])?></td><td><?=htmlspecialchars($r['namamenu'])?></td><td><?=htmlspecialchars($r['harga'])?></td><td><?=htmlspecialchars($r['kategori'])?></td><td><?=htmlspecialchars(($r['ukuran_cup']?:$r['varianrasa'])?:'-')?></td><td><a href="?edit=<?=urlencode($r['id_menu'])?>">Edit</a> | <a href="?delete=<?=urlencode($r['id_menu'])?>" onclick="return confirm('Yakin?')">Hapus</a></td></tr>
<?php endwhile; ?></table>
<?php include 'footer.php'; ?>