<?php include 'db.php'; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cafe Admin</title>

<style>
/* RESET */
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial, sans-serif}

/* LAYOUT */
body{
    display:flex;
    background:#F4F6F9;
}

/* SIDEBAR */
.sidebar{
    width:240px;
    height:100vh;
    background:#A38C55;
    color:white;
    padding:25px 15px;
}

.brand{
    font-size:20px;
    font-weight:bold;
    text-align:center;
    margin-bottom:30px;
    color:#f1c40f;
}

.sidebar a{
    display:block;
    color:#ddd;
    padding:12px 15px;
    margin:6px 0;
    border-radius:8px;
    text-decoration:none;
    transition:.3s;
}

.sidebar a:hover{
    background:#8C7B4A;
    color:#fff;
}

/* CONTENT */
.main{
    flex:1;
    padding:30px;
}

/* TOP BAR */
.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.topbar h2{
    font-size:22px;
}

.logout{
    background:#A38C55;
    padding:8px 16px;
    color:white;
    border-radius:8px;
    text-decoration:none;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 4px 10px rgba(0,0,0,0.05);
}

th,td{
    padding:12px 14px;
    border-bottom:1px solid #eee;
}

th{
    background:#f1f1f1;
    text-align:left;
}

/* FORMS */
form{
    background:white;
    padding:20px;
    border-radius:12px;
    margin-bottom:20px;
    box-shadow:0 4px 10px rgba(0,0,0,0.04);
}

input, select, button{
    padding:10px;
    margin:5px 0;
}

button{
    background:#f1c40f;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
}

/* MESSAGE */
.msg{
    padding:12px;
    margin:10px 0;
    border-radius:8px;
}

.success{background:#e9fce9}
.error{background:#fde0e0}

/* DASHBOARD CARDS */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}

.card{
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 4px 12px rgba(0,0,0,0.05);
    text-align:center;
}

.card h3{
    color:#555;
    font-size:16px;
}

.card h1{
    font-size:32px;
    margin-top:10px;
}
</style>
</head>

<body>

<div class="sidebar">
    <div class="brand">Coffe & Cheesecake</div>

    <a href="index.php">Dashboard</a>
    <a href="pelanggan.php">Pelanggan</a>
    <a href="admin.php">Admin</a>
    <a href="menu.php">Menu</a>
    <a href="kopi.php">Kopi</a>
    <a href="cheesecake.php">Cheesecake</a>
    <a href="pesanan.php">Pesanan</a>
    <a href="detail_pesanan.php">Detail Pesanan</a>
</div>

<div class="main">
    <div class="topbar">
        <h2>Dashboard Cafe</h2>
        <?php if(isset($_SESSION['loggedin'])): ?>
            <a class="logout" href="logout.php">Logout</a>
        <?php endif;?>
    </div>