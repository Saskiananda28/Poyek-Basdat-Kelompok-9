<?php
session_start();

if(!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}

include 'header.php';

// ringkasan
$pel = pg_fetch_row(pg_query($conn, "SELECT COUNT(*) FROM Pelanggan"));
$menu = pg_fetch_row(pg_query($conn, "SELECT COUNT(*) FROM Menu"));
$orders = pg_fetch_row(pg_query($conn, "SELECT COUNT(*) FROM Pesanan"));
$admin = pg_fetch_row(pg_query($conn, "SELECT COUNT(*) FROM AdminCafe"));
?>

<h1 style="margin-bottom:20px;">Selamat Datang, <?= $_SESSION['username']; ?></h1>

<div class="cards">
    <div class="card">
        <h3>Total Pelanggan</h3>
        <h1><?= $pel[0] ?></h1>
    </div>

    <div class="card">
        <h3>Total Menu</h3>
        <h1><?= $menu[0] ?></h1>
    </div>

    <div class="card">
        <h3>Total Pesanan</h3>
        <h1><?= $orders[0] ?></h1>
    </div>

    <div class="card">
        <h3>Total Admin</h3>
        <h1><?= $admin[0] ?></h1>
    </div>
</div>

<?php include 'footer.php'; ?>