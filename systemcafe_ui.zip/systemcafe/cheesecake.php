<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include 'header.php';
?>

<?php

// Create Cheesecake
if(isset($_POST['create_cheese'])){
    $id = $_POST['id_menu'];
    $varian = $_POST['varian'];

    $res = pg_query_params($conn,
        "INSERT INTO Cheesecake (ID_Menu, VarianRasa) VALUES ($1, $2)",
        array($id, $varian)
    );

    if($res) echo '<div class="msg success">Cheesecake ditambahkan.</div>';
    else echo '<div class="msg error">'.pg_last_error($conn).'</div>';
}

// Delete Cheesecake
if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    $res = pg_query_params($conn,
        "DELETE FROM Cheesecake WHERE ID_Menu=$1",
        array($id)
    );

    if($res) echo '<div class="msg success">Cheesecake dihapus.</div>';
}

// Ambil data
$result = pg_query($conn,
    "SELECT c.*, m.NamaMenu
     FROM Cheesecake c
     JOIN Menu m ON c.ID_Menu = m.ID_Menu
     ORDER BY c.ID_Menu"
);
?>

<h1>Data Cheesecake</h1>

<h3>Tambah Cheesecake</h3>
<form method="post">
    <input name="id_menu" placeholder="ID Menu (M00X)" required>
    <input name="varian" placeholder="Varian Rasa" required>
    <button name="create_cheese">Simpan</button>
</form>

<h3>Daftar Cheesecake</h3>
<table>
<tr>
    <th>ID Menu</th>
    <th>Nama Menu</th>
    <th>Varian Rasa</th>
    <th>Aksi</th>
</tr>

<?php while($r = pg_fetch_assoc($result)): ?>
<tr>
    <td><?= $r['id_menu'] ?></td>
    <td><?= $r['namamenu'] ?></td>
    <td><?= $r['varianrasa'] ?></td>
    <td>
        <a href="?delete=<?= $r['id_menu'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
